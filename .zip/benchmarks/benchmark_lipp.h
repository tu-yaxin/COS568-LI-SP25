#pragma once
#include "benchmark.h"

void benchmark_64_lipp(tli::Benchmark<uint64_t>& benchmark);
