var searchData=
[
  ['reverse_5fiterator',['reverse_iterator',['../a00016.html#af0a70641f2216cc31420487a62dd3b0d',1,'stx::btree::iterator::reverse_iterator()'],['../a00011.html#af0a70641f2216cc31420487a62dd3b0d',1,'stx::btree::const_reverse_iterator::reverse_iterator()']]]
];
