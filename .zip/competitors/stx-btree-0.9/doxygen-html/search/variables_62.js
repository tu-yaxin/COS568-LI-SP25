var searchData=
[
  ['binsearch_5fthreshold',['binsearch_threshold',['../a00003.html#a5f30b3761385f6d26acbd2ad1f91c95a',1,'stx::btree_default_set_traits::binsearch_threshold()'],['../a00002.html#ae636c1898e7978b0ca36cebd8fe86319',1,'stx::btree_default_map_traits::binsearch_threshold()']]]
];
