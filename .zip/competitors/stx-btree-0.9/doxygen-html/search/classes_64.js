var searchData=
[
  ['dump_5fheader',['dump_header',['../a00012.html',1,'stx::btree']]]
];
