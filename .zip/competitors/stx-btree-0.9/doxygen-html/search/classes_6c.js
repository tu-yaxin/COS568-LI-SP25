var searchData=
[
  ['leaf_5fnode',['leaf_node',['../a00017.html',1,'stx::btree']]]
];
