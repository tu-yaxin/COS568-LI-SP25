# FINEdex
Pengfei Li, Yu Hua, Jingnan Jia, Pengfei Zuo, “FINEdex: A Fine-grained Learned Index Scheme for Scalable and Concurrent Memory Systems”, Proceedings of the 48th International Conference on Very Large Data Bases (VLDB), 2022.
